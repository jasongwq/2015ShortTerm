/********************************************************************
                            ��ϿƼ�
��ַ��http://www.ourhc.cn
��Ʒ�����Ա��꣺http://shop36330473.taobao.com   
*********************************************************************/
#include <reg52.H>

/****************************************************************************
					24C08 ��д��������	��ʼ
*****************************************************************************/
#include <reg52.H>
#include <stdio.h>
#include <absacc.h>
#define uchar unsigned char 
#define uint unsigned int

sbit scl=P3^3;  //24c02 SCL
sbit sda=P3^4;  //24c02 SDA

uchar x24c02_read(uchar address); //��24c02�ĵ�ַaddress�ж�ȡһ���ֽ�����
void x24c02_write(uchar address,uchar info);
  //��24c02��address��ַ��д��һ�ֽ�����info
void x24c02_init();   //24c02��ʼ���ӳ���
void delay1(uchar x);
void flash();
void x24c01_init();
void start();
void stop();
void writex(uchar j);
uchar readx();
void clock();
void delay1(uchar x)
{
   uint i;
   for(i=0;i<x;i++);
}
void flash()
{}
void x24c02_init()
{
   scl=1; flash(); sda=1; flash();
}
void start()
{
   sda=1; flash(); scl=1; flash(); sda=0; flash(); scl=0; flash();
}
void stop()
{
   sda=0; flash(); scl=1; flash(); sda=1; flash();
}
void writex(uchar j)
{
   uchar i,temp;
   temp=j;
   for (i=0;i<8;i++){
      temp=temp<<1; scl=0; flash(); sda=CY; flash(); scl=1; flash();
   }
   scl=0; flash(); sda=1; flash();
}
uchar readx()
{
   uchar i,j,k=0;
   scl=0; flash(); sda=1;
   for (i=0;i<8;i++){
      flash(); scl=1; flash();
      if (sda==1) j=1;
      else j=0;
      k=(k<<1)|j; scl=0;
   }
   flash(); return(k);
}
void clock()
{
   uchar i=0;
   scl=1; flash();
   while ((sda==1)&&(i<255))i++;
   scl=0; flash();
}
uchar x24c02_read(uchar address)
{
   uchar i;
   start(); writex(0xa0);
   clock(); writex(address);
   clock(); start();
   writex(0xa1); clock();
   i=readx(); stop();
   delay1(10);
   return(i);
}
void x24c02_write(uchar address,uchar info)
{
   EA=0;
   start(); writex(0xa0);
   clock(); writex(address);
   clock(); writex(info);
   clock(); stop();
   EA=1;
   delay1(50);
}


//====================================================================//
 main()
 {
signed char sec; //������ֵ
x24c02_init(); //��ʼ��24C08
sec=x24c02_read(2);//������������ݸ���sec

//sec=10;	//����ʹ�ô���

sec--;
x24c02_write(2,sec); //��24c08 �ĵ�ַ2 ��д������sec

while(1)
{
if(sec>=1)P2=0XAA;	 //��ʾ���

}
} 
